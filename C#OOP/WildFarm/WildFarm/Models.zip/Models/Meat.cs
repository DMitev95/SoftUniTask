﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    internal class Meat : Food
    {
        public Meat(int quantity) : base(quantity)
        {
        }
    }
}
