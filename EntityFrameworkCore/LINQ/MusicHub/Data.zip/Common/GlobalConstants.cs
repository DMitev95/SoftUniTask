﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MusicHub.Common
{
    public static class GlobalConstants
    {
        //Song
        public const int SongNameMxLenght = 20;
        //Album
        public const int AlbumNameLenght = 40;
        //Performer
        public const int PerformarName = 20;
        //Producer
        public const int ProducerName = 30;
    }
}
